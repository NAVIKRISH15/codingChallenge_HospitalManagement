package com.java.connect;
import java.sql.*;
public class DataConnect {
	private static Connection conn=null;
	private DataConnect() {

	/*String url="jdbc:mysql://localhost:3306/EcommerceApp";
	String username="root";
	String password="DiviNavi@15";*/

	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","DiviNavi@15");
	System.out.println("connected to the database");
	}
	catch(Exception e) {
		System.out.println(e);
	}
}
	public static Connection getConnect() {
		DataConnect d1 = new DataConnect();
		return conn;
	}

}
