package com.java.model;

public class Doctor {
public int doctorId;
public String firstName;
public String LastName;
public String Specialization;
public long contactNumber;

public Doctor(){
	
}

public Doctor(int doctorId,String firstName,String LastName,String Specialization,long contactNumber)
{
	this.doctorId=doctorId;
	this.firstName=firstName;
	this.LastName=LastName;
	this.Specialization=Specialization;
	this.contactNumber=contactNumber;
	
}

public int getDoctorId() {
	return doctorId;
}

public void setDoctorId(int doctorId) {
	this.doctorId = doctorId;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return LastName;
}

public void setLastName(String lastName) {
	LastName = lastName;
}

public String getSpecialization() {
	return Specialization;
}

public void setSpecialization(String specialization) {
	Specialization = specialization;
}

public long getContactNumber() {
	return contactNumber;
}

public void setContactNumber(long contactNumber) {
	this.contactNumber = contactNumber;
}
public String toString() {
	return "Doctor[doctor_id="+doctorId+"firstName="+firstName+"LastName="+LastName+"Speciality="+Specialization+"contactNumber="+contactNumber+"]";
	
}
}
