package com.java.model;

public class Patient {
public int patientId;
public String firstName;
public String lastName;
public String dob;
public String gender;
public long ContactNumber;
public String address;

public Patient() {
	
}

public Patient(int patientId,String firstName,String lastName,String dob,String gender,long ContactNumber,String address) {
	this.patientId=patientId;
	this.firstName=firstName;
	this.lastName=lastName;
	this.dob=dob;
	this.gender=gender;
	this.ContactNumber=ContactNumber;
	this.address=address;
}

public long getContactNumber() {
	return ContactNumber;
}

public void setContactNumber(long contactNumber) {
	ContactNumber = contactNumber;
}

public int getPatientId() {
	return patientId;
}

public void setPatientId(int patientId) {
	this.patientId = patientId;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getDob() {
	return dob;
}

public void setDob(String dob) {
	this.dob = dob;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String toString() {
	return "Patient[PatientId="+patientId+"firstNAme="+firstName+"lastname="+lastName+"DateOdBirth="+dob+"gender="+gender+"address="+address+"]";
}
}
