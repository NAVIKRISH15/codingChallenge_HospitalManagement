package com.java.demo.service;
import java.util.Scanner;
import com.java.demo.dao.*;
import com.java.model.*;
import java.util.*;
import myExceptions.*;

public class Service {
Scanner sc;
HospitalDao hdao;
List<Appointment> ap = new ArrayList<Appointment>();

public Service() {
	sc=new Scanner(System.in);
	hdao=new HospitalDao();
	
}

public void getAppointmentById() {
Appointment ap=new Appointment();
	
	System.out.println("enter the appointment Id:");
	ap.setAppointmentId(sc.nextInt());
	hdao.getAppointById(ap.appointmentId);
}

public List<Appointment> getAppointmentsForPatient() throws PatientNumberNotFoundException{
    List<Appointment> pat = new ArrayList<Appointment>();
    
    	
       System.out.println("enter patient id");
       int patientId=sc.nextInt();
       pat=hdao.getAppointmentPatient(patientId);
    
    return pat;
}
    
    public List<Appointment> getAppointmentsForDoctor() {
	    List<Appointment> doc = new ArrayList<Appointment>();
	    
	    	
	       System.out.println("Enter Doctor Id");
	       int doctorId=sc.nextInt();
	       doc=hdao.getAppointmentDoctor(doctorId);
	    
	    return doc;
    }


public void scheduleAppointment() {
	Appointment ap=new Appointment();
	
	System.out.println("enter the appointment Id:");
	ap.setAppointmentId(sc.nextInt());
	
	System.out.println("enter the patient Id:");
	ap.setPatientId(sc.nextInt());
	
	System.out.println("enter the doctor Id:");
	ap.setDoctorId(sc.nextInt());
	
	System.out.println("enter the appointment Date");
	sc.nextLine();
	ap.setAppointmentDate(sc.nextLine());
	
	System.out.println("enter the description");
	ap.setDescription(sc.nextLine());
	
	hdao.scheduleAppointment(ap);
	
}

public void cancelAppointment() {
Appointment ap=new Appointment();
	
	System.out.println("enter the appointment Id:");
	ap.setAppointmentId(sc.nextInt());
	hdao.cancelAppointment(ap.appointmentId);
}

public void updateAppointment() {
Appointment ap=new Appointment();
	
	System.out.println("enter the appointment Id:");
	ap.setAppointmentId(sc.nextInt());
	
	
	System.out.println("enter the appointment Date");	
	sc.nextLine();
	ap.setAppointmentDate(sc.nextLine());

	
	boolean up=hdao.updateAppointment(ap);
	if(up) {
		System.out.println("updated Successfully");
		
	}
	else {
		System.out.println("updation failed");
	}
	
}



}


