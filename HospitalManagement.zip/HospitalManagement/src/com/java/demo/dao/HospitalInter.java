package com.java.demo.dao;
import java.util.List;
import myExceptions.*;
import com.java.model.*;


public interface HospitalInter {
	  Appointment getAppointById(int appointmentId);
	  List<Appointment> getAppointmentPatient(int patientId) throws PatientNumberNotFoundException;
	  List<Appointment> getAppointmentDoctor(int doctorId);
	  boolean scheduleAppointment(Appointment ap);
	  boolean updateAppointment(Appointment ap) ;
	  boolean cancelAppointment(int appointmentId);
}