package com.java.demo.dao;
import com.java.model.*;
import myExceptions.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import com.java.connect.DataConnect;

public class HospitalDao implements HospitalInter {
	 public Connection con;
     PreparedStatement stat;
     
     public HospitalDao() {
    	 con=DataConnect.getConnect();
     }
     
     
     public Appointment getAppointById(int appointmentId) {
    	   
     	try {
     	    stat = con.prepareStatement("select * from appointment where appointmentId=?");
     	    stat.setInt(1, appointmentId);
     	    ResultSet rs = stat.executeQuery();

     	    if (rs.next()) {
     	       
     	        System.out.println("AppointmentId: " + rs.getInt("appointmentId"));
     	        System.out.println("PatientId: " + rs.getInt("patientId"));
     	        System.out.println("DoctorId: " + rs.getInt("doctorId"));
     	        System.out.println("Appointment Date: " + rs.getString("appointmentDate"));
     	        System.out.println("Description: " + rs.getString("description"));
     	    } 
     	    else {
     	        System.out.println("Invalid appointment id");
     	    }
     	} 
     	catch (Exception e) {
     	    System.out.println(e.getMessage()); 
     	}
 		return null;
     }

 	public List<Appointment> getAppointmentPatient(int patientId) throws PatientNumberNotFoundException {
       boolean flag=false;
 		try {
 		    stat = con.prepareStatement("select * from appointment where patientId=?");
 		    stat.setInt(1, patientId);
 		    ResultSet rs = stat.executeQuery();

 		    if (rs.next()) {
 		       
 		        System.out.println("AppointmentId: " + rs.getInt("appointmentId"));
 		        System.out.println("PatientId: " + rs.getInt("patientId"));
 		        System.out.println("DoctorId: " + rs.getInt("doctorId"));
 		        System.out.println("Appointment Date: " + rs.getString("appointmentDate"));
 		        System.out.println("Description: " + rs.getString("description"));
 		       flag=true;
 		    }
 		    else
 		    {
 		    	System.out.println("Invalid Patient Id");
 		    	
 		    }
 		    if(flag==false) {
 		    	throw new PatientNumberNotFoundException("Invalid Patient Id");
 		    }
 		}
 		catch (Exception e) {
 			System.out.println(e.getMessage());
 		
 		    
         } 
 			
 		return null;
 	}

 	public List<Appointment> getAppointmentDoctor(int doctorId) {

		try {
		    stat = con.prepareStatement("select * from appointment where doctorId=?");
		    stat.setInt(1, doctorId);
		    ResultSet rs = stat.executeQuery();

		    if (rs.next()) {
		        
		        System.out.println("AppointmentId: " + rs.getInt("appointmentId"));
		        System.out.println("PatientId: " + rs.getInt("patientId"));
		        System.out.println("DoctorId: " + rs.getInt("doctorId"));
		        System.out.println("Appointment Date: " + rs.getString("appointmentDate"));
		        System.out.println("Description: " + rs.getString("description"));
		        
		    }
		    else
		    {
		    	System.out.println("Invalid Doctor Id");
		    	
		    }
		} catch (Exception e) {
			System.out.println(e.getMessage());
		    
        } 
		return null;
 	}	
		
     
     public boolean scheduleAppointment(Appointment ap) {
         
         try {
             
             stat = con.prepareStatement("insert into Appointment values(?, ?, ?, ?,?)");
             stat.setInt(1, ap.getAppointmentId());
             stat.setInt(2, ap.getPatientId());
             stat.setInt(3, ap.getDoctorId());
             stat.setString(4,ap.getAppointmentDate());
             stat.setString(5, ap.getDescription());
             stat.executeUpdate();
             System.out.println("appointment added sucessfully");
             return true;
         } 
         catch (Exception e) {
             System.out.println(e.getMessage());
             return false;
     
         }

     }
    
     
     public boolean updateAppointment(Appointment ap){
    	
         try {
             
            stat= con.prepareStatement("update appointment set appointmentDate = ? where appointmentId = ?");
             
             stat.setString(1,ap.getAppointmentDate());
             stat.setInt(2,ap.getAppointmentId() );
             
             int rowsaffected = stat.executeUpdate();
           
             
             if(rowsaffected>0)
 			{
 				return true;
 			}
 			else
 				return false;
             } 
         catch (Exception e) {
        	 System.out.println(e.getMessage());
             return false;
         } 
     }
    
 public boolean cancelAppointment(int appointmentId) {
         
         try {
             
             stat = con.prepareStatement("delete from appointment where appointmentId=?");
             stat.setInt(1, appointmentId);
             stat.executeUpdate();
             System.out.println("deleted appointment successfully");
             return true;
         } catch (Exception e) {
        	 System.out.println(e.getMessage());
             return false;
         } 
     }
     
     
     
     
     
     
     
}
