package com.java.client;
import com.java.demo.service.*;
import java.util.*;
public class Main {
public static void main(String args[]) {
	Service obj=new Service();
	Scanner sc=new Scanner(System.in);
	while(true) {
	System.out.println("1.Get appointment by AppointmentId");
	System.out.println("2.Get appointment by PatientId");
	System.out.println("3.Get appointment by DoctorId");
	System.out.println("4.schedule Appointment");
	System.out.println("5.Update Appointment");
	System.out.println("6.cancel Appointment");
	System.out.println("7.Exit");
	System.out.println("enter your choice");
	int ch=sc.nextInt();
	if(ch==1) {
		obj.getAppointmentById();
		
	}
	if(ch==2) {		
		try {
		obj.getAppointmentsForPatient();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			}
		}
	
		
	if(ch==3) {
		obj.getAppointmentsForDoctor();
		
	}
	if(ch==4) {
		obj.scheduleAppointment();
		
	}
	if(ch==5) {
		obj.updateAppointment();
		
	}
	if(ch==6) {
		obj.cancelAppointment();
		
	}
	else {
	
		break;
		
	}
	}
	sc.close();
	
}
}